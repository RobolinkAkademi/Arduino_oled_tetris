/*

   Dpad for Arduino TinyTetris

   Designed for https://github.com/AJRussell/Tiny-Tetris

   Clumsy code by tobozo (c+) 2016
   Apologies for coding horror

*/

#ifndef DPADCPP
#define DPADCPP
#include <Arduino.h>
#define JoyX A0
#define JoyY A1
#define Button 2

const int dpad[5][2] = {
  {460, 480}, //KEY_MIDDLE 0
  {122, 234}, //KEY_LEFT 1
  {700, 750}, //KEY_RIGHT 2
  { -1,   70}, //KEY_DOWN 3
  {260, 350}  //KEY_ROTATE 4
};

static int dpadwarp[5] = { 0, 0, 0, 0, 0 };
static volatile int Debounce = 0;
static volatile bool processKey = true;
static volatile int currentPos;


class Dpad
{

    static const int DebounceMax = 10;

  public:

    static int getPos() {

  
      delay(100);
      int joyx_position = analogRead(JoyX);
      int joyy_position = analogRead(JoyY);
      bool button = digitalRead(Button);
      if (button == 0)
      {
        return 0;
      }
      if (joyx_position < 300)
      {
        return 4;
      }
      if (joyx_position > 700)
      {
        return 3;
      }
      if (joyy_position < 300)
      {
        return 2;
      }
      if (joyy_position > 700)
      {
        return 1;
      }
      return -1;
    }

    static boolean DoDebounce() {
      Debounce++;
      if (Debounce > DebounceMax) {
        return true;
      }
      return false;
    }

    static int setAccel(int acceleration, int offset) {
      if (processKey) {
        dpadwarp[currentPos] = millis();
      }
      if (millis() < dpadwarp[currentPos] + offset) {
        processKey = false;
      } else {
        processKey = true;
        acceleration = acceleration + 70;
        if (acceleration > offset) {
          acceleration = offset;
        }
      }
      return acceleration;
    }



    
};

#endif




